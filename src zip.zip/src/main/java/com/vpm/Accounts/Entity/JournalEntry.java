
package com.vpm.Accounts.Entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@EntityListeners(com.vpm.Accounts.security.TenantEntityListener.class)
public class JournalEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String voucherNumber;

    private LocalDate entryDate;
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private JournalEntryStatus status = JournalEntryStatus.POSTED;

    private LocalDateTime postedAt;
    private String postedBy;
    private Long reversalOfId;

    @Column(name = "tenant_id")
    private Long tenantId;

    @OneToMany(
            mappedBy = "journalEntry",
            cascade = CascadeType.ALL,
            orphanRemoval = true,
            fetch = FetchType.EAGER   // ⚠️ can keep, but see note below
    )
    @JsonManagedReference
    private List<JournalEntryLine> lines = new ArrayList<>();

    // =========================
    // ✅ GETTERS & SETTERS
    // =========================

    public Long getId() {
        return id;
    }

    public String getVoucherNumber(){
        return voucherNumber;
    }

    public void setVoucherNumber(String voucherNumber){
        this.voucherNumber=voucherNumber;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(LocalDate entryDate) {
        this.entryDate = entryDate;
    }

    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate == null || entryDate.isBlank() ? null : LocalDate.parse(entryDate);
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public JournalEntryStatus getStatus() { return status; }
    public void setStatus(JournalEntryStatus status) { this.status = status; }
    public LocalDateTime getPostedAt() { return postedAt; }
    public void setPostedAt(LocalDateTime postedAt) { this.postedAt = postedAt; }
    public String getPostedBy() { return postedBy; }
    public void setPostedBy(String postedBy) { this.postedBy = postedBy; }
    public Long getReversalOfId() { return reversalOfId; }
    public void setReversalOfId(Long reversalOfId) { this.reversalOfId = reversalOfId; }

    public Long getTenantId() { return tenantId; }
    public void setTenantId(Long tenantId) { this.tenantId = tenantId; }

    public List<JournalEntryLine> getLines() {
        return lines;
    }

    public void setLines(List<JournalEntryLine> lines) {
        this.lines = lines;
    }
}
