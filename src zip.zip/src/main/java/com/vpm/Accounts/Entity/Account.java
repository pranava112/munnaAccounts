package com.vpm.Accounts.Entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import com.vpm.Accounts.security.TenantEntityListener;


@Entity
@EntityListeners(TenantEntityListener.class)


public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
   
    @Enumerated(EnumType.STRING)
    private AccountType type;
    
    private String code;
    
    @Column(nullable = false)
    private BigDecimal balance = BigDecimal.ZERO;

    @Column(name = "tenant_id")
    private Long tenantId;

    @Column(nullable = false)
    private boolean active = true;

    @Column(nullable = false)
    private int level = 0;

    @Column(name = "system_account", nullable = false)
    private boolean systemAccount = false;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    public Long getId() {return id;}
    public void setId(Long id) {this.id=id;}
    
    public String getName() {return name;}
    public void setName(String name) {this.name=name;}
    
    public AccountType getType() {return type;}
    public void setType(AccountType type) {this.type=type;}
    
    public String getCode() {return code;}
    public void setCode(String code) {this.code=code;}
    
    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public Long getTenantId() { return tenantId; }
    public void setTenantId(Long tenantId) { this.tenantId = tenantId; }
    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }
    public int getLevel() { return level; }
    public void setLevel(int level) { this.level = level; }
    public boolean isSystemAccount() { return systemAccount; }
    public void setSystemAccount(boolean systemAccount) { this.systemAccount = systemAccount; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }

    @PrePersist
    protected void onCreate() {
        LocalDateTime now = LocalDateTime.now();
        createdAt = now;
        updatedAt = now;
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
    
    // public void debit(BigDecimal amount) {
    //     this.balance += amount;
    // }

    // public void credit(BigDecimal amount) {
    //     this.balance -= amount;
    // }

    public void debit(BigDecimal amount) {
    this.balance = this.balance.add(amount);
}

public void credit(BigDecimal amount) {
    this.balance = this.balance.subtract(amount);
}
    
    
}

// class Account {
//     Long id;
//     String name;
//     Account parent;
//     List<Account> children;
// }