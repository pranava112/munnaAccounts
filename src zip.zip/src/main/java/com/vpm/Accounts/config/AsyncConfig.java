package com.vpm.Accounts.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import com.vpm.Accounts.security.TenantContext;
import org.springframework.core.task.TaskDecorator;

@Configuration
@EnableAsync
public class AsyncConfig {

    @Bean("accountExecutor")
    public Executor accountExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(4);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(50);
        executor.setThreadNamePrefix("account-exec-");
        executor.setTaskDecorator(new TaskDecorator() {
            @Override public Runnable decorate(Runnable task) {
                Long tenantId = TenantContext.get();
                return () -> { try { if (tenantId != null) TenantContext.set(tenantId); task.run(); } finally { TenantContext.clear(); } };
            }
        });
        executor.initialize();
        return executor;
    }
}
