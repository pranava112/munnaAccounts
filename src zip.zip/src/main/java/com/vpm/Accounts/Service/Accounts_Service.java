package com.vpm.Accounts.Service;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vpm.Accounts.Entity.Account;
import com.vpm.Accounts.Repository.AccountRepository;
import com.vpm.Accounts.security.TenantContext;

@Service
@Transactional // Ensures database integrity across async threads
public class Accounts_Service {

    private final AccountRepository accountRepository;
    private final AuditService auditService;

    public Accounts_Service(AccountRepository accountRepository, AuditService auditService) {
        this.accountRepository = accountRepository;
        this.auditService = auditService;
    }

    public CompletableFuture<Account> saveAccountAsync(@NonNull Account account) {
        Account saved = accountRepository.save(account);
        auditService.record("CREATE", "Account", saved.getId(), null, saved.getName());
        return CompletableFuture.completedFuture(saved);
    }

    public CompletableFuture<Optional<Account>> getAccountByIdAsync(@NonNull Long id) {
        return CompletableFuture.completedFuture(accountRepository.findByIdAndTenantId(id, TenantContext.require()));
    }

    public CompletableFuture<Account> updateAccountAsync(@NonNull Long id, @NonNull Account account) {
        return CompletableFuture.completedFuture(
            accountRepository.findByIdAndTenantId(id, TenantContext.require())
                .map(existing -> {
                    String previousName = existing.getName();
                    existing.setName(account.getName());
                    existing.setType(account.getType());
                    existing.setCode(account.getCode());
                    auditService.record("UPDATE", "Account", existing.getId(), previousName, account.getName());
                    return accountRepository.save(existing);
                })
                .orElseThrow(() -> new RuntimeException("Account not found with ID: " + id)));
    }

    public CompletableFuture<Void> deleteAccountAsync(@NonNull Long id) {
        Account account = accountRepository.findByIdAndTenantId(id, TenantContext.require())
            .orElseThrow(() -> new RuntimeException("Account not found with ID: " + id));
        accountRepository.deleteByIdAndTenantId(id, TenantContext.require());
        auditService.record("DELETE", "Account", id, account.getName(), null);
        return CompletableFuture.completedFuture(null);
    }

    public CompletableFuture<List<Account>> getAllAccountsAsync() {
        return CompletableFuture.completedFuture(accountRepository.findAllByTenantId(TenantContext.require()));
    }

    public CompletableFuture<Optional<Account>> findByNameAsync(@NonNull String name) {
        return CompletableFuture.completedFuture(accountRepository.findFirstByNameAndTenantId(name, TenantContext.require()));
    }

    // Read-only hint for optimization
    @Transactional(readOnly = true)
    public Optional<Account> findAllByName(String name) {
        return accountRepository.findFirstByNameAndTenantId(name, TenantContext.require());
    }

    @Transactional(readOnly = true)
    public Optional<Account> findAllByNameIgnoreCase(String name) {
        return accountRepository.findFirstByNameIgnoreCaseAndTenantId(name, TenantContext.require());
    }
}