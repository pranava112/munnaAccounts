
// package com.vpm.Accounts.Service;

// import java.util.ArrayList;
// import java.util.List;
// import java.util.Optional;
// import java.util.concurrent.CompletableFuture;

// import org.springframework.beans.factory.annotation.Autowired;
// import org.springframework.lang.NonNull;
// import org.springframework.scheduling.annotation.Async;
// import org.springframework.stereotype.Service;

// import com.vpm.Accounts.Entity.JournalEntry;
// import com.vpm.Accounts.Entity.JournalEntryLine;
// import com.vpm.Accounts.Repository.JournalEntryRepository;

// @Service
// public class JournalEntryService {

//     @Autowired
//     private JournalEntryRepository repo;

//     public JournalEntry saveJournalEntry(JournalEntry journalEntry) {

//         // ✅ FIX: Now this works correctly
//         if (journalEntry.getLines() == null || journalEntry.getLines().isEmpty()) {
//             throw new RuntimeException("Journal Entry must have at least one line");
//         }

//         double totalDebit = 0;
//         double totalCredit = 0;

//         List<JournalEntryLine> validLines = new ArrayList<>();

//         for (JournalEntryLine line : journalEntry.getLines()) {

//             // Skip invalid rows
//             if (line.getAccount() == null) continue;

//             if (line.getDebit() == 0 && line.getCredit() == 0) continue;

//             // 🔥 IMPORTANT: Set parent
//             line.setJournalEntry(journalEntry);

//             totalDebit += line.getDebit();
//             totalCredit += line.getCredit();

//             validLines.add(line);
//         }

//         if (validLines.isEmpty()) {
//             throw new RuntimeException("No valid journal lines!");
//         }

//         if (totalDebit != totalCredit) {
//             throw new RuntimeException("Debit and Credit must be equal!");
//         }

//         journalEntry.setLines(validLines);

//         return repo.save(journalEntry);
//     }
    
    

//     public List<JournalEntry> getAllEntries() {
//         return repo.findAll();
//     }

//     public Optional<JournalEntry> getEntryById(@NonNull Long id) {
//         return repo.findById(id);
//     }

//     public void deleteEntry(@NonNull Long id) {
//         repo.deleteById(id);
//     }

//     @Async("accountExecutor")
//     public CompletableFuture<JournalEntry> saveJournalEntryAsync(JournalEntry journalEntry) {
//         return CompletableFuture.completedFuture(saveJournalEntry(journalEntry));
//     }

//     @Async("accountExecutor")
//     public CompletableFuture<List<JournalEntry>> getAllEntriesAsync() {
//         return CompletableFuture.completedFuture(getAllEntries());
//     }

//     @Async("accountExecutor")
//     public CompletableFuture<Optional<JournalEntry>> getEntryByIdAsync(@NonNull Long id) {
//         return CompletableFuture.completedFuture(getEntryById(id));
//     }

//     @Async("accountExecutor")
//     public CompletableFuture<Void> deleteEntryAsync(@NonNull Long id) {
//         deleteEntry(id);
//         return CompletableFuture.completedFuture(null);
//     }

//     @Async("accountExecutor")
//     public CompletableFuture<JournalEntry> updateJournalEntryAsync(@NonNull Long id, JournalEntry updatedEntry) {
//         return CompletableFuture.completedFuture(updateJournalEntry(id, updatedEntry));
//     }
    
//     public JournalEntry updateJournalEntry(@NonNull Long id, JournalEntry updatedEntry) {

//         JournalEntry existingEntry = repo.findById(id)
//                 .orElseThrow(() -> new RuntimeException("Journal Entry not found with id: " + id));

//         // ✅ Validate lines
//         if (updatedEntry.getLines() == null || updatedEntry.getLines().isEmpty()) {
//             throw new RuntimeException("Journal Entry must have at least one line");
//         }

//         double totalDebit = 0;
//         double totalCredit = 0;

//         List<JournalEntryLine> validLines = new ArrayList<>();

//         for (JournalEntryLine line : updatedEntry.getLines()) {

//             if (line.getAccount() == null) continue;
//             if (line.getDebit() == 0 && line.getCredit() == 0) continue;

//             // 🔥 SET PARENT
//             line.setJournalEntry(existingEntry);

//             totalDebit += line.getDebit();
//             totalCredit += line.getCredit();

//             validLines.add(line);
//         }

//         if (validLines.isEmpty()) {
//             throw new RuntimeException("No valid journal lines!");
//         }

//         if (totalDebit != totalCredit) {
//             throw new RuntimeException("Debit and Credit must be equal!");
//         }

//         // ✅ UPDATE BASIC FIELDS
//         existingEntry.setEntryDate(updatedEntry.getEntryDate());
//         existingEntry.setDescription(updatedEntry.getDescription());

//         // ✅ CLEAR OLD LINES (IMPORTANT)
//         existingEntry.getLines().clear();

//         // ✅ ADD NEW LINES
//         existingEntry.getLines().addAll(validLines);

//         return repo.save(existingEntry);
//     }
// }



package com.vpm.Accounts.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.time.LocalDate;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;

import com.vpm.Accounts.Entity.JournalEntry;
import com.vpm.Accounts.Entity.JournalEntryLine;
import com.vpm.Accounts.Entity.Account;
import com.vpm.Accounts.Entity.JournalEntryStatus;
import com.vpm.Accounts.Repository.AccountRepository;
import com.vpm.Accounts.Repository.JournalEntryRepository;
import com.vpm.Accounts.security.TenantContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;

@Service
public class JournalEntryService {

    @Autowired
    private JournalEntryRepository repo;

    @Autowired
    private AccountRepository accountRepo;

    @Autowired
    private AuditService auditService;

    private Account requireTenantAccount(Account account) {
        if (account == null || account.getId() == null) {
            throw new IllegalArgumentException("Account is required");
        }
        return accountRepo.findByIdAndTenantId(account.getId(), TenantContext.require())
                .orElseThrow(() -> new SecurityException("Account does not belong to the current company"));
    }

    // =====================================================
    // SAVE JOURNAL ENTRY
    // =====================================================

    @Transactional
    public JournalEntry saveJournalEntry(JournalEntry journalEntry) {

        if (journalEntry.getLines() == null
                || journalEntry.getLines().isEmpty()) {

            throw new RuntimeException(
                    "Journal Entry must have at least one line");
        }

        BigDecimal totalDebit = BigDecimal.ZERO;
        BigDecimal totalCredit = BigDecimal.ZERO;

        List<JournalEntryLine> validLines = new ArrayList<>();

        for (JournalEntryLine line : journalEntry.getLines()) {

            // Skip lines without account
            if (line.getAccount() == null) {
                continue;
            }

            line.setAccount(requireTenantAccount(line.getAccount()));

            BigDecimal debit = line.getDebit();
            BigDecimal credit = line.getCredit();

            // Treat null as zero
            if (debit == null) {
                debit = BigDecimal.ZERO;
            }

            if (credit == null) {
                credit = BigDecimal.ZERO;
            }

            // Skip lines where both are zero
            if (debit.compareTo(BigDecimal.ZERO) == 0
                    && credit.compareTo(BigDecimal.ZERO) == 0) {

                continue;
            }

            // Prevent negative amounts
            if (debit.compareTo(BigDecimal.ZERO) < 0
                    || credit.compareTo(BigDecimal.ZERO) < 0) {

                throw new RuntimeException(
                        "Debit and Credit cannot be negative");
            }

            // Debit and Credit cannot both have values
            if (debit.compareTo(BigDecimal.ZERO) > 0
                    && credit.compareTo(BigDecimal.ZERO) > 0) {

                throw new RuntimeException(
                        "Only one of Debit or Credit should be filled!");
            }

            // Set cleaned values
            line.setDebit(debit);
            line.setCredit(credit);

            // Set parent
            line.setJournalEntry(journalEntry);

            // BigDecimal addition
            totalDebit = totalDebit.add(debit);
            totalCredit = totalCredit.add(credit);

            validLines.add(line);
        }

        // Check valid lines
        if (validLines.isEmpty()) {
            throw new RuntimeException("No valid journal lines!");
        }

        // Check double-entry balance
        if (totalDebit.compareTo(totalCredit) != 0) {

            throw new RuntimeException(
                    "Debit and Credit must be equal! "
                    + "Debit: " + totalDebit
                    + ", Credit: " + totalCredit);
        }

        journalEntry.setLines(validLines);
        journalEntry.setStatus(JournalEntryStatus.POSTED);
        journalEntry.setPostedAt(LocalDateTime.now());
        journalEntry.setPostedBy(SecurityContextHolder.getContext().getAuthentication().getName());

        JournalEntry saved = repo.save(journalEntry);
        if (auditService != null) {
            auditService.record("CREATE", "JournalEntry", saved.getId(), null, saved.getVoucherNumber());
        }
        return saved;
    }

    // =====================================================
    // GET ALL ENTRIES
    // =====================================================

    public List<JournalEntry> getAllEntries() {
        return repo.findAllByTenantId(TenantContext.require());
    }

    // =====================================================
    // GET ENTRY BY ID
    // =====================================================

    public Optional<JournalEntry> getEntryById(@NonNull Long id) {
        return repo.findByIdAndTenantId(id, TenantContext.require());
    }

    // =====================================================
    // DELETE ENTRY
    // =====================================================

    @Transactional
    public void deleteEntry(@NonNull Long id) {
        JournalEntry entry = repo.findByIdAndTenantId(id, TenantContext.require())
                .orElseThrow(() -> new IllegalArgumentException("Journal entry not found"));
        if (entry.getStatus() == JournalEntryStatus.POSTED) {
            throw new IllegalStateException("Posted entries cannot be deleted; reverse the entry instead");
        }
        repo.deleteByIdAndTenantId(id, TenantContext.require());
        if (auditService != null) {
            auditService.record("DELETE", "JournalEntry", id, entry.getVoucherNumber(), null);
        }
    }

    // =====================================================
    // ASYNC SAVE
    // =====================================================

    public CompletableFuture<JournalEntry> saveJournalEntryAsync(
            JournalEntry journalEntry) {

        return CompletableFuture.completedFuture(
                saveJournalEntry(journalEntry)
        );
    }

    // =====================================================
    // ASYNC GET ALL
    // =====================================================

    public CompletableFuture<List<JournalEntry>> getAllEntriesAsync() {

        return CompletableFuture.completedFuture(
                getAllEntries()
        );
    }

    // =====================================================
    // ASYNC GET BY ID
    // =====================================================

    public CompletableFuture<Optional<JournalEntry>> getEntryByIdAsync(
            @NonNull Long id) {

        return CompletableFuture.completedFuture(
                getEntryById(id)
        );
    }

    // =====================================================
    // ASYNC DELETE
    // =====================================================

    public CompletableFuture<Void> deleteEntryAsync(
            @NonNull Long id) {

        deleteEntry(id);

        return CompletableFuture.completedFuture(null);
    }

    // =====================================================
    // ASYNC UPDATE
    // =====================================================

    public CompletableFuture<JournalEntry> updateJournalEntryAsync(
            @NonNull Long id,
            JournalEntry updatedEntry) {

        return CompletableFuture.completedFuture(
                updateJournalEntry(id, updatedEntry)
        );
    }

    // =====================================================
    // UPDATE JOURNAL ENTRY
    // =====================================================

    public JournalEntry updateJournalEntry(
            @NonNull Long id,
            JournalEntry updatedEntry) {

        JournalEntry existingEntry = repo.findByIdAndTenantId(id, TenantContext.require())
                .orElseThrow(() ->
                        new RuntimeException(
                                "Journal Entry not found with id: " + id));

                if (existingEntry.getStatus() == JournalEntryStatus.POSTED) {
                    throw new IllegalStateException("Posted entries cannot be edited; reverse the entry instead");
                }

        // Validate lines
        if (updatedEntry.getLines() == null
                || updatedEntry.getLines().isEmpty()) {

            throw new RuntimeException(
                    "Journal Entry must have at least one line");
        }

        BigDecimal totalDebit = BigDecimal.ZERO;
        BigDecimal totalCredit = BigDecimal.ZERO;

        List<JournalEntryLine> validLines = new ArrayList<>();

        for (JournalEntryLine line : updatedEntry.getLines()) {

            // Skip lines without account
            if (line.getAccount() == null) {
                continue;
            }

            line.setAccount(requireTenantAccount(line.getAccount()));

            BigDecimal debit = line.getDebit();
            BigDecimal credit = line.getCredit();

            // Treat null as zero
            if (debit == null) {
                debit = BigDecimal.ZERO;
            }

            if (credit == null) {
                credit = BigDecimal.ZERO;
            }

            // Skip zero lines
            if (debit.compareTo(BigDecimal.ZERO) == 0
                    && credit.compareTo(BigDecimal.ZERO) == 0) {

                continue;
            }

            // Prevent negative amounts
            if (debit.compareTo(BigDecimal.ZERO) < 0
                    || credit.compareTo(BigDecimal.ZERO) < 0) {

                throw new RuntimeException(
                        "Debit and Credit cannot be negative");
            }

            // Debit and Credit cannot both have values
            if (debit.compareTo(BigDecimal.ZERO) > 0
                    && credit.compareTo(BigDecimal.ZERO) > 0) {

                throw new RuntimeException(
                        "Only one of Debit or Credit should be filled!");
            }

            line.setDebit(debit);
            line.setCredit(credit);

            // Set parent
            line.setJournalEntry(existingEntry);

            // Add totals
            totalDebit = totalDebit.add(debit);
            totalCredit = totalCredit.add(credit);

            validLines.add(line);
        }

        // Validate lines
        if (validLines.isEmpty()) {
            throw new RuntimeException("No valid journal lines!");
        }

        // Validate balanced entry
        if (totalDebit.compareTo(totalCredit) != 0) {

            throw new RuntimeException(
                    "Debit and Credit must be equal! "
                    + "Debit: " + totalDebit
                    + ", Credit: " + totalCredit);
        }

        // Update basic fields
        existingEntry.setEntryDate(
                updatedEntry.getEntryDate());

        existingEntry.setDescription(
                updatedEntry.getDescription());

        // Clear old lines
        existingEntry.getLines().clear();

        // Add new lines
        existingEntry.getLines().addAll(validLines);

        JournalEntry saved = repo.save(existingEntry);
        if (auditService != null) {
            auditService.record("UPDATE", "JournalEntry", saved.getId(), "posted=" + existingEntry.getVoucherNumber(), saved.getVoucherNumber());
        }
        return saved;
    }

    @Transactional
    public JournalEntry reverseEntry(@NonNull Long id) {
        JournalEntry original = repo.findByIdAndTenantId(id, TenantContext.require())
                .orElseThrow(() -> new IllegalArgumentException("Journal entry not found"));
        if (original.getStatus() != JournalEntryStatus.POSTED) {
            throw new IllegalStateException("Only posted entries can be reversed");
        }

        JournalEntry reversal = new JournalEntry();
        reversal.setVoucherNumber(original.getVoucherNumber() + "-REV-" + System.currentTimeMillis());
        reversal.setEntryDate(LocalDate.now());
        reversal.setDescription("Reversal of " + original.getVoucherNumber());
        reversal.setStatus(JournalEntryStatus.POSTED);
        reversal.setPostedAt(LocalDateTime.now());
        reversal.setPostedBy(SecurityContextHolder.getContext().getAuthentication().getName());
        reversal.setReversalOfId(original.getId());

        List<JournalEntryLine> reversalLines = new ArrayList<>();
        for (JournalEntryLine originalLine : original.getLines()) {
            JournalEntryLine line = new JournalEntryLine();
            line.setAccount(originalLine.getAccount());
            line.setDebit(originalLine.getCredit());
            line.setCredit(originalLine.getDebit());
            line.setJournalEntry(reversal);
            reversalLines.add(line);
        }
        reversal.setLines(reversalLines);
        JournalEntry saved = repo.save(reversal);
        original.setStatus(JournalEntryStatus.REVERSED);
        repo.save(original);
        if (auditService != null) {
            auditService.record("REVERSE", "JournalEntry", original.getId(), original.getVoucherNumber(), saved.getVoucherNumber());
        }
        return saved;
    }
}