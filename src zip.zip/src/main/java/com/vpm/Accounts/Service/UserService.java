package com.vpm.Accounts.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.util.Set;
import org.springframework.stereotype.Service;

import com.vpm.Accounts.Entity.Users;
import com.vpm.Accounts.Repository.UserRepository;

@Service
public class UserService {
    private static final Set<String> SUPPORTED_ROLES = Set.of("OWNER", "ACCOUNTANT", "SALES_USER", "PURCHASE_USER", "AUDITOR", "VIEWER", "ADMIN");

    @Autowired
    private UserRepository repo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Users saveUsers(Users user){
        if (user.getPassword() != null && !user.getPassword().startsWith("$2a$") && !user.getPassword().startsWith("$2b$") && !user.getPassword().startsWith("$2y$")) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        if (user.getRole() == null || user.getRole().isBlank()) {
            user.setRole("VIEWER");
        } else {
            user.setRole(user.getRole().replaceFirst("^ROLE_", "").toUpperCase());
            if (!SUPPORTED_ROLES.contains(user.getRole())) {
                throw new IllegalArgumentException("Unsupported role: " + user.getRole());
            }
        }
        if (user.getTenantId() == null) {
            user.setTenantId(com.vpm.Accounts.security.TenantContext.require());
        }
        return repo.save(user);
    }
    
}
