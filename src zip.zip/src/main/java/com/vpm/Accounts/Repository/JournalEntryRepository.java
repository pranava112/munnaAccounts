// package com.vpm.Accounts.Repository;

// import org.springframework.data.jpa.repository.JpaRepository;

// import com.vpm.Accounts.Entity.JournalEntry;

// // public interface JournalEntryRepository extends JpaRepository<JournalEntry,Long> {

// // }

// public interface JournalEntryRepository extends JpaRepository<JournalEntry, Long> {
// }



package com.vpm.Accounts.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import com.vpm.Accounts.Entity.JournalEntry;
import com.vpm.Accounts.security.TenantRepositorySupport;

public interface JournalEntryRepository
        extends JpaRepository<JournalEntry, Long>, TenantRepositorySupport<JournalEntry> {

    Optional<JournalEntry> findByVoucherNumberAndTenantId(String voucherNumber, Long tenantId);

    @Modifying
    @Transactional

        void deleteByVoucherNumberAndTenantId(String voucherNumber, Long tenantId);
}