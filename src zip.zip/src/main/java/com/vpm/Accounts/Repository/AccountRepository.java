//package com.vpm.Accounts.Repository;
//
//import java.util.Optional;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.vpm.Accounts.Entity.Account;
//import com.vpm.Accounts.Entity.Product;
//
//public interface AccountRepository extends JpaRepository<Account,Long> {
//
////	Optional<Product> findByName(String string);
//
//}



package com.vpm.Accounts.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vpm.Accounts.Entity.Account;
import com.vpm.Accounts.security.TenantRepositorySupport;

public interface AccountRepository extends JpaRepository<Account, Long>, TenantRepositorySupport<Account> {

    // Use first matching account to avoid non-unique result errors
    Optional<Account> findFirstByNameAndTenantId(String name, Long tenantId);
    Optional<Account> findFirstByNameIgnoreCaseAndTenantId(String name, Long tenantId);

    @Deprecated Optional<Account> findFirstByName(String name);
    @Deprecated Optional<Account> findFirstByNameIgnoreCase(String name);

    // If there are duplicate names, allow listing all matches for diagnostics/fallback
    List<Account> findAllByNameAndTenantId(String name, Long tenantId);
    List<Account> findAllByNameIgnoreCaseAndTenantId(String name, Long tenantId);

}