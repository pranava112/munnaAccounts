package com.vpm.Accounts.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import java.util.List;

import com.vpm.Accounts.Entity.Users;

public interface UserRepository extends JpaRepository<Users, Long>{
	Optional<Users> findByUsername(String username);
	Optional<Users> findByEmail(String email);
	boolean existsByUsername(String username);
	boolean existsByEmail(String email);
	List<Users> findAllByTenantId(Long tenantId);
}
